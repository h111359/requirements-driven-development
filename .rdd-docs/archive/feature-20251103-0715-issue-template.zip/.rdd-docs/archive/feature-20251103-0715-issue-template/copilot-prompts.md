## Stand Alone Prompts

Prompts that the agent execute - follow the instructions which prompts to be executed. If nothing provided - execute only one prompt - the first not executed and stop. When a given prompt is executed, the checkbox in front of it should be marked. Changing the checkbox to `- [x]` is **the only change you are allowed to do**. Never change anything else than marking a checkbox! 

 - [x] [P01] Check `.rdd/scripts/rdd.sh` and all scripts in `.rdd/scripts` and propose changes so during the execution of `.github/prompts/rdd.01-initiate.prompt.md` to be copied `.rdd/templates/copilot-prompts.md` to `.rdd-docs/workspace` for both options - enh and fix
  
 - [x] [P02] Remove adding `.rdd-docs/workspace/open-questions.md` to the `.rdd-docs/workspace` folder. Read `.rdd/scripts/README.md` and find out in which script in `.rdd/scripts` should be made this change. 

 - [ ] [P03] <PROMPT-PLACEHOLDER>
 
 - [ ] [P04] <PROMPT-PLACEHOLDER>

 - [ ] [P05] <PROMPT-PLACEHOLDER>