## Stand Alone Prompts

Prompts that the agent execute - follow the instructions which promts to be executed. If nothing provided - execute only one prompt - the first not executed and stop. When a given prompt is executed, the checkbox infront of it should be marked. Changing the checkbox to `- [x]` is **the only change you are allowed to do**. Never change anything else than marking a checkbox! 

 - [ ] [P01] <PROMPT-PLACEHOLDER>
  
 - [ ] [P02] <PROMPT-PLACEHOLDER>

 - [ ] [P03] <PROMPT-PLACEHOLDER>
 
 - [ ] [P04] <PROMPT-PLACEHOLDER>

 - [ ] [P05] <PROMPT-PLACEHOLDER>