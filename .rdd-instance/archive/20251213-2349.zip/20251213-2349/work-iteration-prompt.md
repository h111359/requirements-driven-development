# Prompt 

Read the whole project file by file and create a "concepts-test.md" in the workspace folder, containing a list of concepts you uess are valid but still are not reflected in `.rdd-docs/concepts.md`