# Questionnaire — 20251213-2349 (Genrate context additions)

**Context**
This work-iteration prompt asks to “read the whole project file by file” and produce a `concepts-test.md` list of concepts that are valid for the project but missing from `.rdd-docs/concepts.md`.

Some parts are underspecified (what depth counts as “concept”, and how strict the definition should be). Please answer the questions below so the generated `concepts-test.md` matches your preferences.

---

## 1) Concept granularity

**Q: What level of granularity should a “concept” in `concepts-test.md` have?**

Please choose one:
- [ ] **A)** High-level product/workflow concepts only (similar to existing CON-00X items)
  - **Pros:** Stays aligned with the intent of `concepts.md`
  - **Cons:** May miss useful lower-level terms that the codebase relies on
- [x] **B)** Mix of high-level concepts + key implementation concepts (e.g., “domain routing”, “workspace archiving snapshot”, “session token”)
  - **Pros:** More complete conceptual map of how the framework works
  - **Cons:** Larger list; may include items that feel “too technical”
- [ ] **C)** Very detailed: include internal terms, functions/commands, file schemas, and operational details as concepts
  - **Pros:** Maximum coverage
  - **Cons:** Can blur concepts vs. specs/requirements; list may be long
- [ ] **D)** Other (please specify): 

---

## 2) Strictness: “missing from concepts.md”

**Q: When is a concept considered “already reflected” in `.rdd-docs/concepts.md`?**

Please choose one:
- [ ] **A)** Only if it is explicitly present as a numbered concept item (e.g., CON-012)
- [x] **B)** If it is explicitly mentioned anywhere in the text (even if not enumerated)
- [ ] **C)** If it is implicitly covered by a broader concept (e.g., “Web UI” covers “REST endpoints”)
- [ ] **D)** Other (please specify): 

---

## 3) Output structure preference

**Q: How should `concepts-test.md` be structured?**

Please choose one:
- [ ] **A)** Simple bullet list of candidate concepts (fast to review)
- [ ] **B)** Numbered list where each item includes: concept name + 1–2 sentence justification + where it appears (files)
- [x] **C)** Table with columns: Concept, Why it exists, Evidence (files), Suggested location in `concepts.md`
- [ ] **D)** Other (please specify): 

---

## 4) Scope of “read the whole project”

**Q: What scope should I use for “read the whole project file by file”?**

Please choose one:
- [ ] **A)** Focus on documentation and the `.rdd/` and `.rdd-docs/` framework code only (ignore build/tests unless they introduce concepts)
- [x] **B)** Include everything: docs + scripts + tests + build tooling (treat tests/build as concept sources too)
- [ ] **C)** Prioritize core; sample only the rest (e.g., inspect a representative subset of tests)
- [ ] **D)** Other (please specify): 
